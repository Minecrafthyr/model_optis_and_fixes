Copied 11 files from "[Vanilla Tweaks](https://vanillatweaks.net/)/NicerFastLeaves" under [Vanilla Tweaks - Terms and Conditions](https://vanillatweaks.net/terms/).

### Files

assets/minecraft/textures/block/

- acacia_leaves.png
- azalea_leaves.png
- birch_leaves.png
- cherry_leaves.png
- dark_oak_leaves.png
- flowering_azalea_leaves.png
- jungle_leaves.png
- mangrove_leaves.png
- oak_leaves.png
- spruce_leaves.png


overlay_51/assets/minecraft/textures/block/pale_oak_leaves.png