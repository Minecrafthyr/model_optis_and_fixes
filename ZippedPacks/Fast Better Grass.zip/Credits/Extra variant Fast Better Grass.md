Modified 8 files from [Fast Better Grass](https://modrinth.com/resourcepack/fast-better-grass) by [Fabulously Optimized](https://modrinth.com/organization/fabulously-optimized)/[robotkoer](https://modrinth.com/user/robotkoer) under [MIT License](https://spdx.org/licenses/MIT.html):

Assets/Extra/Fast Better Grass/assets/minecraft/models/block

- crimson_nylium.json
- dirt_path.json
- grass_block.json
- grass_block_snow.json
- mycelium.json
- podzol.json
- warped_nylium.json

Assets/Extra/Fast Better Grass/assets/res_fixes/models/block/fast_better_grass.json