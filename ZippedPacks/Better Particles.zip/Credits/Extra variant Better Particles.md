Modified 9 files from "[Vanilla Tweaks](https://vanillatweaks.net/)/Unobtrusive Particles" under [Custom License](https://vanillatweaks.net/terms/).

### Files

assets/minecraft/textures/particle/

- effect_0.png
- effect_1.png
- effect_2.png
- effect_3.png
- effect_4.png
- effect_5.png
- effect_6.png
- effect_7.png
- heart.png