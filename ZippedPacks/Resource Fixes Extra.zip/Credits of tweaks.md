Credits:

[Vanilla Tweaks](https://vanillatweaks.net/) (Modified)

Packs:

- ItemHoldFix
