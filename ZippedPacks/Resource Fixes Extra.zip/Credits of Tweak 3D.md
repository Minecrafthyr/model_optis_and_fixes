From Just 3D by sniffercraft34 (modified):

- assets/minecraft/models/block/redstone_dust_dot.json
- assets/minecraft/models/block/redstone_dust_side_alt.json
- assets/minecraft/models/block/redstone_dust_side.json
- assets/minecraft/models/block/redstone_dust_up.json
