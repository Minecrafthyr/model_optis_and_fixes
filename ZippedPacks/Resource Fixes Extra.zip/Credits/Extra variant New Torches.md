Modified 4 files from [New Torches](https://modrinth.com/resourcepack/new-torches) by [Waradu](https://modrinth.com/user/Waradu) under [MIT License](https://spdx.org/licenses/MIT.html):

Assets/Extra/New Torches/assets/res_fixes/textures/block

- redstone_torch_off.png
- redstone_torch.png
- soul_torch.png
- torch.png
