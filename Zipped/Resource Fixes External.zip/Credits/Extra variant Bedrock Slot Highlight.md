Unmodified 2 files from "[Vanilla Tweaks](https://vanillatweaks.net/)/BedrockSlotHighlight" under [Custom License](https://vanillatweaks.net/terms/):

Assets/Extra/Bedrock Slot Highlight/assets/minecraft/textures/gui/sprites/container

- slot_highlight_front.png
- slot_highlight_back.png