Modified 4 files from [Just 3D](https://modrinth.com/resourcepack/EnOq8vEP) by [sniffercraft34](https://modrinth.com/user/sniffercraft34) under [MIT License](https://spdx.org/licenses/MIT.html):

assets/minecraft/models/block/

- redstone_dust_dot.json
- redstone_dust_side_alt.json
- redstone_dust_side.json
- redstone_dust_up.json
