Unmodified 45 files from "[Vanilla Tweaks](https://vanillatweaks.net/)/NicerFastLeaves" under [Custom License](https://vanillatweaks.net/terms/):

Assets/Extra/Better Leaves/assets/minecraft/blockstates

- acacia_leaves.json
- azalea_leaves.json
- birch_leaves.json
- cherry_leaves.json
- dark_oak_leaves.json
- flowering_azalea_leaves.json
- jungle_leaves.json
- mangrove_leaves.json
- oak_leaves.json
- pale_oak_leaves.json
- spruce_leaves.json

Assets/Extra/Better Leaves/assets/minecraft/models/block

- acacia_leaves_waterlogged.json
- azalea_leaves_waterlogged.json
- birch_leaves_waterlogged.json
- cherry_leaves_waterlogged.json
- dark_oak_leaves_waterlogged.json
- flowering_azalea_leaves_waterlogged.json
- jungle_leaves_waterlogged.json
- mangrove_leaves_waterlogged.json
- oak_leaves_waterlogged.json
- pale_oak_leaves_waterlogged.json
- spruce_leaves_waterlogged.json

Assets/Extra/Better Leaves/assets/minecraft/textures/block/

- acacia_leaves.png
- acacia_leaves_waterlogged.png
- azalea_leaves.png
- azalea_leaves_waterlogged.png
- birch_leaves.png
- birch_leaves_waterlogged.png
- cherry_leaves.png
- cherry_leaves_waterlogged.png
- dark_oak_leaves.png
- dark_oak_leaves_waterlogged.png
- flowering_azalea_leaves.png
- flowering_azalea_leaves_waterlogged.png
- jungle_leaves.png
- jungle_leaves_waterlogged.png
- mangrove_leaves.png
- mangrove_leaves_waterlogged.png
- oak_leaves.png
- oak_leaves_waterlogged.png
- pale_oak_leaves.png
- pale_oak_leaves_waterlogged.png
- spruce_leaves.png
- spruce_leaves_waterlogged.png
