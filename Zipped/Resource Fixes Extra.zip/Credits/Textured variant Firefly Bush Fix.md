Unmodified 2 files from [Fix Firefly Bush](https://modrinth.com/resourcepack/firefly-bush-fix) under [MIT License](https://spdx.org/licenses/MIT.html):

Assets/Textured/Firefly Bush Fix/assets/minecraft/textures/block

- firefly_bush_emissive.png
- firefly_bush_emissive.png.mcmeta